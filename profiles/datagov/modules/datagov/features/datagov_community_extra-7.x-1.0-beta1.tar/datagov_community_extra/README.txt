This extra feature contains code that is not safe to include in the main feature.
